import streamlit as st
import pandas as pd
import numpy as np
from sklearn.neighbors import NearestNeighbors
from sklearn.decomposition import TruncatedSVD
from sklearn.preprocessing import MinMaxScaler
from scipy.sparse import csr_matrix

# Load the dataset
df = pd.read_csv('udemy_courses_with_student_performance.csv')

# Preprocess data
df['Student_Interest'] = df['Student_Interest'].astype('category').cat.codes
features = ['Student_Interest', 'Course_Rating', 'Student_Performance']

# Normalize features for content-based filtering
scaler = MinMaxScaler()
normalized_features = scaler.fit_transform(df[features])

# Content-Based Filtering
knn = NearestNeighbors(n_neighbors=5, metric='cosine')
knn.fit(normalized_features)

# Content-based recommendation function
def recommend_courses_content_based(course_features, top_n=5):
    distances, indices = knn.kneighbors([course_features])
    return df.iloc[indices[0]]['course_title'].values[:top_n]

# Collaborative filtering setup
student_course_matrix = df.pivot(index='Student_ID', columns='course_title', values='Student_Performance').fillna(0)
sparse_matrix = csr_matrix(student_course_matrix.values)

# Apply SVD
svd = TruncatedSVD(n_components=10, random_state=42)
latent_matrix = svd.fit_transform(sparse_matrix)

# Collaborative recommendation function
def recommend_courses_collaborative(student_id, top_n=5):
    student_idx = student_course_matrix.index.get_loc(student_id)
    student_latent = latent_matrix[student_idx]
    similarities = np.dot(latent_matrix, student_latent)
    recommended_idx = np.argsort(-similarities)[1:top_n+1]  # Exclude self
    return student_course_matrix.columns[recommended_idx]

# Hybrid recommendation function
def hybrid_recommendation(student_id, course_features, top_n=5):
    # Content-based recommendations
    content_based = recommend_courses_content_based(course_features, top_n=top_n)
    
    # Collaborative filtering recommendations
    collaborative = recommend_courses_collaborative(student_id, top_n=top_n)
    
    # Combine recommendations: Intersection or weighted union
    final_recommendations = list(set(content_based).intersection(set(collaborative)))
    if len(final_recommendations) < top_n:
        # Fill up with union if intersection is small
        union = list(set(content_based).union(set(collaborative)))
        final_recommendations.extend(union[:top_n - len(final_recommendations)])
    
    return final_recommendations[:top_n]

# Streamlit Interface
st.title("Course Recommendation System")

# Sidebar for inputs
st.sidebar.header("Student and Course Details")
student_id = st.sidebar.text_input("Enter Student ID", "Student_4")
interest = st.sidebar.slider("Student Interest (0-5)", 0, 5, 3)
rating = st.sidebar.slider("Course Rating (0.0-5.0)", 0.0, 5.0, 4.5)
performance = st.sidebar.slider("Student Performance (%)", 0.0, 100.0, 85.0)

# Main content
if st.sidebar.button("Recommend Courses"):
    course_features = [interest, rating, performance]
    hybrid_recommendations = hybrid_recommendation(student_id, course_features)
    
    st.subheader("Hybrid Recommendations")
    for i, course in enumerate(hybrid_recommendations, 1):
        course_row = df[df['course_title'] == course].iloc[0]  # Get the row for the course
        course_url = course_row['url']  # Assuming this column contains the URL
        st.markdown(f"{i}. [{course}]({course_url})")  # Create a clickable hyperlink

# Metrics Visualization
precision = 1.0
recall = 0.67
f1_score = 0.8

metrics = ['Precision', 'Recall', 'F1 Score']
values = [precision, recall, f1_score]

st.subheader("Model Evaluation Metrics")
st.bar_chart(pd.DataFrame({"Metric": metrics, "Value": values}).set_index("Metric"))
