#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import joblib

# Load the data
file_path = r"C:\Users\Student\Desktop\crop_pred\yield_df.csv.zip"
df = pd.read_csv(file_path)

# Preprocess the data: select relevant columns
df = df[["Area", "average_rain_fall_mm_per_year", "avg_temp", "pesticides_tonnes", "hg/ha_yield"]]
df = pd.get_dummies(df, columns=["Area"], drop_first=True)  # One-hot encode 'Area'

# Define features and target
X = df.drop(columns=["hg/ha_yield"])
y = df["hg/ha_yield"]

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model
model = LinearRegression()
model.fit(X_train, y_train)

# Evaluate the model
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
print(f"Mean Squared Error: {mse:.2f}")

# Save the model
joblib.dump(model, "crop_yield_model.pkl")
print("Model saved as crop_yield_model.pkl")


# In[ ]:




