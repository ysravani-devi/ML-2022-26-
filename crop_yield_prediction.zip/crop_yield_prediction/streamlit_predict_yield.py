#!/usr/bin/env python
# coding: utf-8

# In[4]:


import streamlit as st
import pandas as pd
import numpy as np
import joblib

# Load the trained model
model = joblib.load(r"C:\Users\Student\Desktop\crop_pred\crop_yield_model.pkl")

# Load dataset to get available areas
file_path = r"C:\Users\Student\Desktop\crop_pred\yield_df.csv.zip"
df = pd.read_csv(file_path)
areas = df["Area"].unique()

# Streamlit interface
st.title("Crop Yield Prediction")

st.sidebar.header("Input Features")

# User inputs
area = st.sidebar.selectbox("Select Area", areas)
rainfall = st.sidebar.number_input("Average Rainfall (mm/year)", min_value=0.0, value=500.0, step=10.0)
temperature = st.sidebar.number_input("Average Temperature (°C)", min_value=-10.0, value=25.0, step=0.5)
pesticides = st.sidebar.number_input("Pesticides Used (tonnes)", min_value=0.0, value=50.0, step=1.0)

# Predict button
if st.sidebar.button("Predict Yield"):
    # Prepare input for prediction
    area_columns = [f"Area_{area}" for area in areas if f"Area_{area}" in df.columns]
    area_values = [1 if area == selected_area else 0 for selected_area in areas]

    # Ensure input data has the correct number of features
    input_data = np.array([rainfall, temperature, pesticides] + area_values).reshape(1, -1)
    
    # Ensure it has 103 features (drop extra features if any)
    if input_data.shape[1] > 103:
        input_data = input_data[:, :-1]  # Drop the last column if it exceeds 103 features

    # Make prediction
    prediction = model.predict(input_data)[0]
    
    # Display prediction
    st.write(f"### Estimated Yield: {prediction:.2f} hg/ha")


# In[ ]:




